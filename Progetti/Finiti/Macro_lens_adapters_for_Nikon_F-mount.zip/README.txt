                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:621794
Macro lens adapters for Nikon F-mount by Physics_Dude is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Look at those two sample pictures! Wow!  

You can now give any Nikon F-mount lenses or adapters a super macro super power!  

**UPDATE:** Added a new retention ring for lens-side mounting. **No tools or rubber bands needed!** Just snap it onto any macro adapter and check that its protruding tip meshes with the cosponsoring locking hole on your lens. I put two to a plate so printers will have time to let the previous layers cool when it comes to printing the thin locking nib.  

**UPDATE 2:** Strengthened retention ring for lens-side mounting. 

**In Use:**
The two sample pictures were taken with a 40mm and 80mm printed adapter stacked on top of each other with a Minolta 50mm F/2 lens and lens-less F-mount to MD/SR-mount converter. No cropping was done. (minimum focal distance for this setup is roughly 65mm or 2.5in)  

The demo video titled "Tiny things on a 3D printer" was recorded with an 80mm printed adapter (predecessor version; see below) and Minolta 50mm F/2. http://youtu.be/D8-BCeOGRiQ  

Locking example video (see Instructions) was recorded with 20mm printed adapter and a Nikkor 35mm F/1.8.  

**Features:**  
1) Built-in tab opens aperture all the way on Nikkor lenses that do not have manual aperture control. This tab can be broken off or shortened if desired. (see "d" in the Instructions for more control options)  

2) These are designed to mesh precisely with the locks on both the camera body and lens for safe use. (~~lens-side lock pin requires rubber band~~ Lens-side requires new C-clip)  

3) Lenses remain in the same orientation as they would without these adapters (name-plates up).  

4) Three sizes are provided; 20mm, 40mm, and 80mm.  

5) You can stack them.  

6) These may be printed without support, though the aperture tab may fail to function fully.  

See *Instructions* for more tips.  

Also check out my F to SR-mount macro adapter, the predecessor to this design: http://www.thingiverse.com/thing:619663  




# Instructions

**Tips:**  
a) Start small (20mm). Not all lenses work well with the larger adapters. You'll still be surprised with the results.  

b) These are perfect for use with other mount-type conversion adapters and old or fast lenses with full manual control.  

c) ~~A lens-lock key is provided separate from the main models. Use a rubber band to keep it from falling out. To use these locks, watch this video. http://youtu.be/F9BbPP3m9OI~~ Use the newer C-clips to lock your lenses. See second picture above.  

d) You can achieve manual control with Nikkor lenses that do not have a manual aperture ring by omitting the lens-side lock and turning the lens body within its mount.