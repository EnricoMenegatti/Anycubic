                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2711059
Clamps by iomaa is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

<p>Please see our popular <a href="http://www.iomaa.com">binary titanium key carabiners</a> made from pure titanium, with the safety cage to keep your keys secure, and the built-in bottle opener.</p>
<p>
</p>


<p>
Fully functional clamps, assembled (just add rubber bands).

</p>



# Our
other thingiverse projects:

<p>
<strong>
<a href="https://www.thingiverse.com/thing:2676324"> measuring cube</a></strong> |
<strong>
<a href="https://www.thingiverse.com/thing:2638683"> juice squeezer</a></strong> |
<strong>
<a href="https://www.thingiverse.com/thing:2835728"> USB and SD holder</a></strong> |
<strong>
<a href="https://www.thingiverse.com/thing:2421018"> fire truck</a></strong> |
<strong>
<a href="https://www.thingiverse.com/thing:2505369"> print wedges</a></strong> |
<strong>
<a href="https://www.thingiverse.com/iomaa/designs"> more...</a></strong>.
</p>


![Alt text](https://cdn.thingiverse.com/assets/f6/ec/4f/f3/34/66.png)

# Clamps

<p>
<strong>Clamp A</strong> | Similar to a standard “spring” clamp | Size: regular | Height 145 mm (5.7”) | Clamp opening: 80 mm (3.2”) | Clamp reach: 52 mm (2”) | Smaller sizes: scale it down | Larger sizes: scale it up | Standard clamping strength:  use a few rubber bands | Weaker clamping strength: use less rubber bands | Strong clamping strength: add some rubber bands | Extra strong: add even more bands.
</p>

<p>
<strong>…………………… </strong>
</p>

<p>
<strong>Clamp B</strong> | Similar to a standard “photo” clamp | Size: regular | Height 145 mm (5.7”) | Clamp opening: 76 mm (3”) | Clamp reach: 52 mm (2”) | Smaller sizes: scale it down | Larger sizes: scale it up | Standard clamping strength:  use a few rubber bands | Weaker clamping strength: use less rubber bands | Strong clamping strength: add some rubber bands | Extra strong: add even more bands.

</p>

<p>
<strong>…………………… </strong>
</p>



<p>
We printed PLA at 0.2 mm layer, 70% infill or more (you do need strength for this one).
</p>

<p>
Supports: NONE (please don’t use any supports, they will fuse parts and the clamp will not work)
</p>

<p></p>

<p>
<strong>…………………… </strong>
</p>




<p>
The Clamps are protected by US patent pending.
</p>



<p>Enjoy</p>